<?php
    
    $username = $_GET['username']??'tugceden';
    $limit    = $_GET['limit']??12;
    
    require "insta_rate.php";
    
    use insta_rate\insta_rate;
    
    $insta_rate = new insta_rate($username,'json');
    
    $user_info = $insta_rate->user_avg();
    print_r($user_info);
    
    /*
    $userinfo   = get_inst_info($username, $limit);
    $inf_res    = influencer_calc($userinfo->posts);
    $user_avg   = user_avg($userinfo->total_likes, $userinfo->total_comments, $userinfo->total_followers, $limit);
    $user_rates = user_rates($userinfo->total_likes, $userinfo->total_comments, $userinfo->total_followers, $limit);
    
    print_r($user_rates);
    */
    
    /*
    
    echo 'Toplam '.$total_like.' beğeni ve toplam '.$total_comment.' yorum <br>';
    echo 'Toplam Ortalama '.$rate_like.' beğeni ve toplam ortalama '.$rate_comment.' yorum <br>';
    
    $rate           = rate_calc($total_like, $total_comment, $follow_count);
    $rate_rate      = rate_calc($pure_rate_like, $pure_rate_comment, $follow_count);
    $last_rate_rate = rate_calc($last_pure_rate_like, $last_pure_rate_comment, $follow_count);
    
    echo $username.' kullanıcısının etkileşim last oranı %'.number_format($last_rate_rate, 2).'<br>';
    echo $username.' kullanıcısının etkileşim oranı %'.number_format($rate, 2).'<br>';
    echo $username.' kullanıcısının etkileşim oranı %'.number_format($rate_rate, 2).'<br>';
    echo $last_total_like.'<br>';
    echo $username.' kullanıcısının katılım oranı %'.number_format($last_total_like / $follow_count, 10);
    */
    
    /*
    function rate_calc($like_count, $comment_count, $follower_count, $number_format = false){
        if($number_format == true){
            return number_format((($like_count + $comment_count) / $follower_count) * 100, 2);
        }else{
            return (($like_count + $comment_count) / $follower_count) * 100;
        }
    }
    
    function get_inst_info($username, $limit = 12){
        
        $insta_link = 'https://www.instagram.com/'.$username.'/?__a=1';
        
        $insta_json = file_get_contents($insta_link);
        $insta_json = json_decode($insta_json);
        
        $user = $insta_json->graphql->user;
        
        $total_followers    = $user->edge_followed_by->count;
        $posts              = $user->edge_owner_to_timeline_media->edges;
        $total_posts        = $user->edge_owner_to_timeline_media->count;
        $total_likes        = 0;
        $total_comments     = 0;
        $limit_count        = 0;
        $posts_info         = [];
        
        foreach($posts as $id => $post){
            
            $p             = $post->node;
            $post_likes    = $p->edge_liked_by->count;
            $post_comments = $p->edge_media_to_comment->count;
            
            $posts_info[] = [
                'id'             => $p->shortcode,
                'total_likes'    => $post_likes,
                'total_comments' => $post_comments,
            ];
            
            //echo ($id + 1).'. paylaşım toplam '.$post_like.' beğeni ve toplam '.$post_comment.' yorum | Etileşim '.rate_calc($post_like, $post_comment, $follow_count, true).'<br>';
            
            $total_likes    += $post_likes;
            $total_comments += $post_comments;
            
            if($limit_count == ($limit - 1)){
                break;
            }else{
                $limit_count++;
            }
        }
        
        return (object) [
            'total_likes'     => $total_likes,
            'total_comments'  => $total_comments,
            'total_followers' => $total_followers,
            'total_posts'     => $total_posts,
            'posts'           => (object) $posts_info,
        ];
    }
    
    function influencer_calc($posts){
        
        $inf_total_likes    = 0;
        $inf_total_comments = 0;
        
        foreach($posts as $id => $post){
            if($id >= 3 and $id <= 9){
                $inf_total_likes    += $post['total_likes'];
                $inf_total_comments += $post['total_comments'];
            }
        }
        
        return [
            'inf_total_likes'    => $inf_total_likes,
            'inf_total_comments' => $inf_total_comments,
        ];
    }
    
    function user_avg($total_likes = 0, $total_comments = 0, $total_followers = 0, $limit = 12){
        
        $like_avg    = $total_likes / $limit;
        $comment_avg = $total_comments / $limit;
        
        return [
            'like_avg'           => $like_avg,
            'comment_avg'        => $comment_avg,
            'format_like_avg'    => number_format($like_avg, 2),
            'format_comment_avg' => number_format($comment_avg, 2),
            'rate'               => rate_calc($total_likes, $total_comments, $total_followers),
        ];
    }
    
    function user_rates($total_likes = 0, $total_comments = 0, $total_followers = 0, $limit = 12){
    
        influencer_calc();
        
        return [
            'general_rate' => rate_calc($total_likes, $total_comments, $total_followers),
            'general_rate' => rate_calc($total_likes, $total_comments, $total_followers),
        ];
        
    }
    */