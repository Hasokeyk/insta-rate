<?php
    
    
    namespace insta_rate;
    
    
    class insta_rate{
        
        public $instagram_url = 'https://www.instagram.com/-{USERNAME}-/?__a=1';
        public $username;
        public $user;
        public $limit = 12;
        public $total_likes;
        public $total_comments;
        public $total_followers;
        
        function __construct($username, $type = 'web'){
            
            $this->username = $username;
            
            if(!empty($username)){
                $this->user = $this->get_inst_info($username, $type);
            }
            
        }
        
        function get_inst_info($username = null, $type = 'web', $limit = 12){
            
            if($type == 'json'){
                $insta_link = ($username??$this->username).'.json';
            }else{
                $insta_link = 'https://www.instagram.com/'.($username??$this->username).'/?__a=1';
            }
            
            $insta_json = file_get_contents($insta_link);
            $insta_json = json_decode($insta_json);
            
            $user            = $insta_json->graphql->user;
            $total_followers = $user->edge_followed_by->count;
            $posts           = $user->edge_owner_to_timeline_media->edges;
            $total_posts     = $user->edge_owner_to_timeline_media->count;
            $total_likes     = 0;
            $total_comments  = 0;
            $limit_count     = 0;
            $posts_info      = [];
            
            foreach($posts as $id => $post){
                
                $p             = $post->node;
                $post_likes    = $p->edge_liked_by->count;
                $post_comments = $p->edge_media_to_comment->count;
                
                $posts_info[] = [
                    'id'             => $p->shortcode,
                    'total_likes'    => $post_likes,
                    'total_comments' => $post_comments,
                ];
                
                //echo ($id + 1).'. paylaşım toplam '.$post_like.' beğeni ve toplam '.$post_comment.' yorum | Etileşim '.rate_calc($post_like, $post_comment, $follow_count, true).'<br>';
                
                $total_likes    += $post_likes;
                $total_comments += $post_comments;
                
                if($limit_count == ($limit - 1)){
                    break;
                }else{
                    $limit_count++;
                }
            }
            
            $this->total_likes     = $total_likes;
            $this->total_comments  = $total_comments;
            $this->total_followers = $total_followers;
            $this->posts           = $posts;
            
            return (object) [
                'total_likes'     => $total_likes,
                'total_comments'  => $total_comments,
                'total_followers' => $total_followers,
                'total_posts'     => $total_posts,
                'posts'           => (object) $posts_info,
            ];
        }
        
        function inf_posts_calc($posts = null){
            
            $inf_posts_total_likes    = 0;
            $inf_posts_total_comments = 0;
            
            foreach(($posts??$this->posts) as $id => $post){
                if($id >= 3 and $id <= 9){
                    $inf_posts_total_likes    += ($post->total_likes??$this->total_likes);
                    $inf_posts_total_comments += ($post->total_comments??$this->total_comments);
                }
            }
            
            return (object) [
                'inf_posts_total_likes'    => $inf_posts_total_likes,
                'inf_posts_total_comments' => $inf_posts_total_comments,
            ];
        }
        
        function user_avg($total_likes = 0, $total_comments = 0, $total_followers = 0, $limit = 12){
            
            $total_likes     = ($total_likes??$this->total_likes);
            $total_comments  = ($total_comments??$this->total_comments);
            $total_followers = ($total_followers??$this->total_followers);
            $limit = ($limit??$this->limit);
            
            $like_avg    = $total_likes / $limit;
            $comment_avg = $total_comments / $limit;
            
            return (object) [
                'like_avg'           => $like_avg,
                'comment_avg'        => $comment_avg,
                'format_like_avg'    => number_format($like_avg, 2),
                'format_comment_avg' => number_format($comment_avg, 2),
                'rate'               => $this->rate_calc($total_likes, $total_comments, $total_followers),
            ];
        }
        
        function user_rates($total_likes = 0, $total_comments = 0, $total_followers = 0, $limit = 12){
            
            $inf_calc = $this->inf_posts_calc($this->user->posts);
            
            return (object) [
                'general_rate' => $this->rate_calc($total_likes, $total_comments, $total_followers),
                'avg_rate'     => $this->rate_calc($inf_calc->inf_posts_total_likes, $inf_calc->inf_posts_total_comments, $total_followers),
            ];
            
        }
        
        function insta_rate_result(){
            
            $inf_res  = $this->inf_posts_calc($this->user->posts);
            $user_avg = $this->user_avg($this->user->total_likes, $this->user->total_comments, $this->user->total_followers, $this->limit);
            print_r($user_avg);
            $user_rate = $this->user_rates($user_avg->like_avg, $user_avg->comment_avg, $this->user->total_followers, $this->limit);
            
            return $user_rate;
            
        }
        
        function rate_calc($like_count, $comment_count, $follower_count, $number_format = false){
            
            echo $like_count;
            echo $comment_count;
            echo $follower_count;
            exit();
            
            if($number_format == true){
                return number_format((($like_count + $comment_count) / $follower_count) * 100, 2);
            }else{
                return (($like_count + $comment_count) / $follower_count) * 100;
            }
        }
        
        
    }